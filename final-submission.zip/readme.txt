CSE 507

Remy Oukaour
Ganesa Thandavam
Omar Khazamov

Our report is at doc/report.pdf.
Our source code is in src/, eval/, and public_html/.
Our database is on Dropbox at:
https://dl.dropboxusercontent.com/u/24474628/tfidf-d80-t2.5-indexed-tfidf-desc.db.7z
The Wikipedia data we started with is on Dropbox at:
https://dl.dropboxusercontent.com/u/24474628/enwiki-2013-04-04-pages-articles.7z
